<?php

/**
 * Nombre: ctp_flights.class
 * Detalle: Controla todas las funciones para el modulo de flights.
 * company: Iatai Andina
 * @author: John Fredy Velasco Bareño
 * fecha de creacion: Septiembre de 2014
 * @link jvelasco@iatai.com
 * @copyright 2014 - Iatai Andina - Todos los derechos reservados. 
 */
class ctp_flights {
    
    /**
    * Genera la peticion para consultar el api de viajes.
    *
    * @return array con los datos de la respuesta del api.
    * @param array $post con los datos para enviar al api. 
    */
    static function ctp_flights_send_post($post){
        $url = base_url_fly . 'Vuelos/Resultados';
        $options = array();
        $options['data'] = $post;
        $options['data'] = http_build_query($options['data']);
        $options['method'] = 'POST';
        $headers = array('Content-Type' => 'application/x-www-form-urlencoded');
        $options['headers'] = $headers;
        $response = drupal_http_request($url, $options);
        return $response;        
    }

    /**
    * Cambia el formato de la fecha para enviar al api.
    *
    * @return string con la fecha con el formato correcto del api.
    * @param string $date con la fecha. 
    */    
    static function ctp_flights_formmat_date($date) {
        list ($month, $day, $year) = explode("/", $date);
        return $year . '-' . $month . '-' . $day;
    }

    /**
    * Obtiene el valor del tipo de viaje para enviar al api.
    *
    * @return string con el tipo correcto del api.
    * @param string $key con la llave a buscar. 
    */
    static function ctp_flights_types($key) {
        $arrayTypes = array(
            1 => "RT",
            2 => "OW",
            3 => "MD"
        );
        return $arrayTypes[$key];
    }
}

?>
