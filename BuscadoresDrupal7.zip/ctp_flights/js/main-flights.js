if (typeof Das === "undefined")
    var Das = {};

(function($) {
    //var baseurl = 'https://autoaereo.globalti.co/';
	var baseurl = 'https://Autocompletar.allegra.travel/';
	var _language = 'en';
	
    var _autoCompleteAirport = function($form) {
        //source: baseurl + "Vuelos/json_aeropuertos",
        var $thisField = $("input[data-autocomplete='cityairport']", $form);
        var $thisHiddenName = "IATA";
        var url = baseurl + "api/values/getinfo?type=json";
        var $objButtonSubmit = $("button.form-submit", $form)

        Das.Main.autoCompleteField($thisField, null, $thisHiddenName, url, $objButtonSubmit, $form);
    };

    var _checkType = function($this, callback) {
        var $contFormFlyDefault = $("div.cont-form-fly-default");
        var $contFormFlyMultiple = $("div.cont-form-fly-multiple");
        var $contDepartingDate = $("#cont-flight-returning-date");
        var $flightReturingDate = $("input#flight_returing_date");

        var $value = parseInt($this.val());
        
        switch ($value) {
            case 1:
                if ($contFormFlyDefault.is(":hidden")) {
                    $contFormFlyMultiple.fadeOut('fast', function() {
                        $contFormFlyDefault.show();
                    });
                }

                $contDepartingDate.css("visibility", "visible");
                break;
            case 2:
                if ($contFormFlyDefault.is(":hidden")) {
                    $contFormFlyMultiple.fadeOut('fast', function() {
                        $contFormFlyDefault.show();
                    });
                }

                $contDepartingDate.css("visibility", "hidden");
                $flightReturingDate.val("");
                break;
            default:
                $contFormFlyDefault.fadeOut('fast', function() {
                    $contFormFlyMultiple.show();
                });
                break;
        }
        callback.call();
    };

    var _init = function() {
        var
                $contModules = $("#cont-modules"),
                $formFlyDefault = $("form#ctp-flights-form"),
                $formFlyMultiple = $("form#ctp-flights-multiple-form"),
                $flightDepartingDate = $("input#tbl_flight_departing_date", $formFlyDefault),
                $flightReturingDate = $("input#tbl_flight_returing_date", $formFlyDefault);
		
		_language = $contModules.attr("data-language");
		
		$("input:radio[name='flight_types_default']", $formFlyDefault).off().on("change", function() {
            var $this = $(this);
            _checkType($this, function() {

                var $input = $("input[name='flight_types_default']", $formFlyDefault);
                if ($this.val() === "3") {
                    $input = $("input[name='flight_types_multiple']", $formFlyMultiple);
                }

                var $inputMax = $($input[parseInt($this.val()) - 1]);
                $inputMax.filter('[value=' + parseInt($this.val()) + ']').prop('checked', true);
            });
        });

        $("input:radio[name='flight_types_multiple']", $formFlyMultiple).off().on("change", function() {
            var $this = $(this);
            _checkType($this, function() {
                var $input = $("input[name='flight_types_default']", $formFlyDefault);
                var $inputMax = $($input[parseInt($this.val()) - 1]);
                $inputMax.filter('[value=' + parseInt($this.val()) + ']').prop('checked', true);
            });
        });

        Das.Main.loadDatePicker($flightDepartingDate, $flightReturingDate, undefined);
        $("input[data-object='datePickerMultiple']", $formFlyMultiple).each(function() {
            Das.Main.loadDatePicker($(this), undefined, undefined);
        });

        var $contMoreReturing = $("#cont-ctp-origen-destino", $formFlyMultiple);

        $("a#btn-ctp-add-journey", $formFlyMultiple).off().on("click", function(e) {
            e.preventDefault();
            var $this = $(this);
            var $contentParentThis = $this.closest("#ctp-add-more-journey");
            var countDestinos = $("div[data-ctpblock='multipledestinos']", $contMoreReturing).length;

            $contentParentThis.show();
            if (countDestinos === 6) {
                return false;
            }

            var $currentContent = $("div#cont-multiple-destino-" + countDestinos, $contMoreReturing);
            $currentContent.clone().appendTo($contMoreReturing);

            var newTotalDestinos = $("div[data-ctpblock='multipledestinos']", $contMoreReturing).length;
            var $newObject = $("div[data-ctpblock='multipledestinos']:nth-child(" + newTotalDestinos + ")");
            _renameObject($newObject, countDestinos, newTotalDestinos, function() {
                _autoCompleteAirport($formFlyMultiple);
                _refreshDatePicker(newTotalDestinos);

                $("a[data-remove-item='multiple']", $newObject).off().on("click", function(e) {
                    e.preventDefault();
                    $newObject.fadeOut("slow", function() {
                        var $this = $(this);
                        $this.remove();
                        _reoderDestino();

                        var countDestinos = $("div[data-ctpblock='multipledestinos']", $contMoreReturing).length;
                        if (countDestinos <= 5)
                            $contentParentThis.show();
                    });

                });
            });

            var countDestinos = $("div[data-ctpblock='multipledestinos']", $contMoreReturing).length;
            if (countDestinos === 6) {
                $contentParentThis.hide();
            }
            Das.Main.scrollTo($("#cont-multiple-destino-" + newTotalDestinos));
        });

        $("select#flight_children_type").off().on("change", function() {
            return false;
            var
                    $this = $(this),
                    $value = parseInt($this.val()),
                    $contentParent = $this.closest("form"),
                    $contentMainAge = $("div[data-age-item='1']", $contentParent);

            var $totalSelects = $("select", $contentMainAge).length;
            var $currentSelect = $("select[name='age_children-1']", $contentMainAge);
            var $currentContentSelect = $(".form-item-age-children-1", $contentMainAge);


            if ($value === 0) {
                $contentMainAge.fadeOut("fast");
                _removeSelectAge(1, $currentContentSelect);
            } else {
                if ($value > $totalSelects) {
                    var $totalToClone = ($value - $totalSelects);
                    _cloneSelectAge($totalSelects, $totalToClone, $currentSelect, $currentContentSelect);
                } else if ($value < $totalSelects) {
                    _removeSelectAge($value, $currentContentSelect);
                }

                $contentMainAge.fadeIn("fast");
            }
        });

        $("a#btn-option-avanzadas", $formFlyDefault).off().on("click", function(e) {
            e.preventDefault();
            var $this = $(this);
            var $textToShow = $this.attr("data-to-show-text");
            var $textToHide = $this.attr("data-to-hide-text");

            _showHideMoreOptions($this, $formFlyDefault, $textToShow, $textToHide);
        });

        $("a#btn-option-avanzadas", $formFlyMultiple).off().on("click", function(e) {
            e.preventDefault();
            var $this = $(this);
            var $textToShow = $this.attr("data-to-show-text");
            var $textToHide = $this.attr("data-to-hide-text");

            _showHideMoreOptions($this, $formFlyMultiple, $textToShow, $textToHide);
        });

        _submitFlyDefault($formFlyDefault);
        _submitFlyMultiple($formFlyMultiple);
        _autoCompleteAirport($formFlyDefault);
        _autoCompleteAirport($formFlyMultiple);

        //$("#cont-submit-flight", $formFlyDefault).append("<span><img id='ajax-loader' src='' /></span>");
        //$("#cont-submit-flight", $formFlyMultiple).append("<span><img id='ajax-loader' src='' /></span>");

    };

    var _showHideMoreOptions = function($this, $mainContent, $textToShow, $textToHide) {
        var $contentMoreOptions = $("#cont-more-options", $mainContent);
        if ($contentMoreOptions.is(":hidden")) {
            $contentMoreOptions.fadeIn("fast", function() {
                $this.html($textToHide);
            });
        } else {
            $contentMoreOptions.fadeOut("fast", function() {
                $this.html($textToShow);
            });
        }
    };

    var _submitFlyMultiple = function($form) {
        var rulesErrors = {
            flight_returing_date: true
        };

        $("#btn_submit_flight_multiple", $form).off().on("click", function(e) {
            e.preventDefault();
            var $this = $(this);
            $this.hide();
            //$("img#ajax-loader", $form).show();

            $(".contenedor-modulo-express").fadeOut("fast", function() {
                $(this).empty();
            });
            $(".contentmetodopagoajax").fadeOut("fast", function() {
                $(this).empty();
            });

            var $contError = $("div#alert-error", $form);
            var $selectChild = $("select#flight_children_type", $form);

            $contError.hide().html("");

            var $objectChild = $("option:selected", $selectChild);
            if ($objectChild.val() > 0) {
                rulesErrors['child'] = true;
            }

            //$form.submit();
            //return false;

            Das.MainForm.validate($form, rulesErrors, function($result) {
                _clearFormError($form);
                if ($result !== true) {
                    var $input = $("[name='" + $result.input + "']", $form);
                    var $error = $.trim($("input[name='error-" + $result.error + "']", $form).val());
                    $input.addClass("error").focus();
                    $("div#alert-error").html($error).show();
                    $("img#ajax-loader", $form).hide();
                    $this.show();
                } else {
                    $(".contentLoading").show();
                    $form.submit();
                }

            });
        });
    };

    var _submitFlyDefault = function($form) {
        var rulesErrors = {
            flight_returing_date: true
        };

        $("#btn_submit_flight", $form).off().on("click", function(e) {
            e.preventDefault();
            var $this = $(this);
            $this.hide();
            $("img#ajax-loader", $form).show();
            $(".contentctptravelajax").fadeOut("fast", function() {
                $(this).empty();
            });
            $(".contentmetodopagoajax").fadeOut("fast", function() {
                $(this).empty();
            });

            //
            var $contError = $("div#alert-error", $form);
            var $contReturningDate = $("#cont-flight-returning-date", $form);
            var $selectChild = $("select#flight_children_type", $form);

            $contError.hide().html("");
            if (!$contReturningDate.is(":hidden"))
                rulesErrors = {};

            var $objectChild = $("option:selected", $selectChild);

            if ($objectChild.val() > 0) {
                rulesErrors['child'] = true;
            }
            
            //$form.submit();
            //return false;
            
            Das.MainForm.validate($form, rulesErrors, function($result) {
                _clearFormError($form);

                if ($result !== true) {
                    var $input = $("[name='" + $result.input + "']", $form);
                    var $error = $.trim($("input[name='error-" + $result.error + "']", $form).val());
                    $input.addClass("error").focus();
                    var $errorContent = $("div#alert-error");
                    $errorContent.html($error).show();
                    Das.Main.scrollTo($errorContent);
                    $("img#ajax-loader", $form).hide();
                    $this.show();
                } else {
                    $(".contentLoading").show();
                    //return false;
                    $form.submit();
                }

            });
        });
    }
    ;

    var _clearFormError = function($form) {
        $("input,select", $form).each(function() {
            $(this).removeClass("error");
        });
    };

    var _cloneSelectAge = function($currentTotal, $totalToClone, $objectToClone, $content) {
        var i = 1;
        while (i <= $totalToClone) {

            var $newObject = $objectToClone.clone().appendTo($content);
            $currentTotal++;
            $newObject.attr("id", "edit-age-children-" + $currentTotal);
            $newObject.attr("name", "age_children-" + $currentTotal);
            $("option", $newObject).each(function() {
                if ($(this).val() === "0")
                    $(this).text("Edad del niño " + $currentTotal);
            });
            $newObject.removeClass("error");
            i++;
        }
    };

    var _removeSelectAge = function($currentTotal, $content) {
        var i = 1;
        $("select", $content).each(function() {
            if (i > $currentTotal) {
                $(this).remove();
            }
            i++;
        });
    };

    var _refreshDatePicker = function(total) {
        var
                $contModules = $("#cont-modules"),
                $contentFly = $("#ctp_flights", $contModules),
                $formFlyMultiple = $("form#ctp-flights-multiple-form", $contentFly);
		
		var lenDatePicker = $("input[data-object='datePickerMultiple']", $formFlyMultiple);
		
		var itr = 1;
		$("input[data-object='datePickerMultiple']", $formFlyMultiple).each(function() {
			console.log("total", total, "itr", itr);
			
            if (total == itr){
				$(this).removeClass('hasDatepicker');
				$(this).datepicker({
					dateFormat: "mm/dd/yy",
					minDate: 0,
					numberOfMonths: 2
				});
				$(this).datepicker("setDate", new Date());
			}
			itr++;
        });
    };

    var _reoderDestino = function() {

        var
                $contModules = $("#cont-modules"),
                $contentFly = $("#ctp_flights", $contModules),
                $formFlyMultiple = $("form#ctp-flights-multiple-form", $contentFly),
                $object = $("#cont-ctp-origen-destino", $formFlyMultiple),
                $destinos = $("div[data-ctpblock='multipledestinos']", $object),
                i = 1;

        $destinos.each(function() {
            var
                    $this = $(this),
                    oldItem = parseInt($this.attr("data-num-item"));

            if (i > 2) {
                var newItem = i;
                $("span#item-ctp-origen-destino-" + oldItem, $this).attr("id", "item-ctp-origen-destino-" + newItem).html(_language == 'en' ? "Destination # "+ newItem : "Destino # " + newItem);

                //from
                $("div.form-item-flight-from-" + oldItem, $this).removeClass("form-item-flight-from-" + oldItem).addClass("form-item-flight-from-" + newItem);
                $("label[for='edit-flight-from-" + oldItem + "']", $this).attr("for", "edit-flight-from-" + newItem);

                var $inputFrom = $("input#flight_from-" + oldItem, $this);
                $inputFrom.attr("name", "flight_from-" + newItem);
                $inputFrom.attr("id", "flight_from-" + newItem);

                //to
                $("div.form-item-flight-to-" + oldItem, $this).removeClass("form-item-flight-to-" + oldItem).addClass("form-item-flight-to-" + newItem);
                $("label[for='edit-flight-to-" + oldItem + "']", $this).attr("for", "edit-flight-to-" + newItem);
                var $inputTo = $("input#flight_to-" + oldItem, $this);
                $inputTo.attr("name", "flight_to-" + newItem);
                $inputTo.attr("id", "flight_to-" + newItem);


                $("div.form-item-flight-departing-date-" + oldItem, $this).removeClass("form-item-flight-departing-date-" + oldItem).addClass("form-item-flight-departing-date-" + newItem);
                $("label[for='edit-flight-departing-date-" + oldItem + "']", $this).attr("for", "edit-flight-departing-date-" + newItem);
                var $inputDate = $("input#flight_departing_date_" + oldItem, $this);
                $inputDate.attr("name", "flight_departing_date-" + newItem);
                $inputDate.attr("id", "flight_departing_date_" + newItem);
                $this.attr("id", "cont-multiple-destino-" + newItem);
                $this.attr("data-num-item", newItem)
            }
            i++;
        });
        _refreshDatePicker(0);
    };

    var _renameObject = function($object, oldItem, newItem, callback) {
        $("span#item-ctp-origen-destino-" + oldItem, $object).attr("id", "item-ctp-origen-destino-" + newItem).html(_language == 'en' ? "Destination # " + newItem: "Destino # " + newItem);

        //from
        $("div.form-item-flight-from-" + oldItem, $object).removeClass("form-item-flight-from-" + oldItem).addClass("form-item-flight-from-" + newItem);
        $("label[for='edit-flight-from-" + oldItem + "']", $object).attr("for", "edit-flight-from-" + newItem);

        var $inputFrom = $("input#flight_from-" + oldItem, $object);
        $inputFrom.val("");
        $inputFrom.attr("name", "flight_from-" + newItem);
        $inputFrom.attr("id", "flight_from-" + newItem);

        //to
        $("div.form-item-flight-to-" + oldItem, $object).removeClass("form-item-flight-to-" + oldItem).addClass("form-item-flight-to-" + newItem);
        $("label[for='edit-flight-to-" + oldItem + "']", $object).attr("for", "edit-flight-to-" + newItem);
        var $inputTo = $("input#flight_to-" + oldItem, $object);
        $inputTo.val("");
        $inputTo.attr("name", "flight_to-" + newItem);
        $inputTo.attr("id", "flight_to-" + newItem);


        $("div.form-item-flight-departing-date-" + oldItem, $object).removeClass("form-item-flight-departing-date-" + oldItem).addClass("form-item-flight-departing-date-" + newItem);
        $("label[for='edit-flight-departing-date-" + oldItem + "']", $object).attr("for", "edit-flight-departing-date-" + newItem);
        var $inputDate = $("input#flight_departing_date_" + oldItem, $object);
        $inputDate.val("");
        $inputDate.attr("name", "flight_departing_date-" + newItem);
        $inputDate.attr("id", "flight_departing_date_" + newItem);

        $object.attr("id", "cont-multiple-destino-" + newItem);
        $object.attr("data-num-item", newItem);
        if ($("#cont-remove-item", $object).length < 1) {
            var $dataRemoveDestinationText = $("div#ctp-add-more-journey");
            var $objRemove = $("<div id='cont-remove-item'><a href='javascript:void(0)' data-remove-item='multiple'>" + $dataRemoveDestinationText.attr("data-remove-destination") + "</a></div>");
            $objRemove.appendTo($object);
        }

        //Das.Main.scrollTo($object);
        callback.call();

    };

    Das.Flight = {
        init: _init
    };

})(jQuery);