<?php
global $base_url, $language;

$formFlight = drupal_get_form(module_custom_name_flights . '_form');
$formMultipleFlight = drupal_get_form(module_custom_name_flights . '_multiple_form');


if (isset($_SESSION["stringParameter"])){
    $dataPost = unserialize($_SESSION["stringParameter"]);
    unset($_SESSION["stringParameter"]);
}
//var_dump($language->language);
?>
<div id="cont-modules" data-language="<?php echo $language->language ?>">
    <div class="contentLoading" style="display: none;"></div>
    <div id="cont-ctp-main">
        <div class="cont-ctp-tabs" id="ctp_flights">
            <div data-rel="ctp-form-fly" class="cont-form-fly-default">
                <?php print drupal_render($formFlight); ?>
            </div>
            <div data-rel="ctp-form-fly" class="cont-form-fly-multiple" style="display: none;">
                <?php print drupal_render($formMultipleFlight); ?>
            </div>
        </div>
    </div>
</div>
<script>
    jQuery(function() {
        var $ = jQuery.noConflict();
        $(".ctp-cont-submit").append("<span><img id='ajax-loader' src='' /></span>");
        $("img#ajax-loader").attr("src", '<?php echo $base_url . '/' . drupal_get_path('module', module_custom_name_main) . '/images/ajax-loader.gif' ?>');
        $("img#ajax-loader").hide();
        
         // Muestra el mensaje de error interno
        var messageForm = "<?php echo isset($dataPost["message"]) ? $dataPost["message"] : '' ; ?>";
        messageForm || ( messageForm = jQuery(".alert").hide().text().substring(15,250) );
        if(messageForm) {
            jQuery("#alert-error").text(messageForm).show();
            jQuery("html, body").scrollTo("#alert-error", 800);
        }
    });
</script>