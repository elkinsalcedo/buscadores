<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of MainHotel
 *
 * @author IATAI
 */
class MainHotel extends MainUtils {

    public static function getHotelList($term) {
        return self::queryToDataBase('iata_cities', 'location AS value, city AS id', 'location', $term);
    }

}