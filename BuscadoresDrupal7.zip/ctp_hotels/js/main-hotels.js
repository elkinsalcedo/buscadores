if (typeof Das === "undefined")
    var Das = {};

(function($) {
	var _language = 'en';
	
    var _removeContentAge = function($item, $contItemRooms) {
        var i = 1;
        $("div[data-items-rooms='age']", $contItemRooms).each(function() {
            if (i > $item) {
                $(this).remove();
            }
            i++;
        });
    };

    var _cloneContentAge = function($currentTotal, $totalToClone, $mainContentRoomsToClone, $contItemRooms) {
        
        var i = 1;
        while (i <= $totalToClone) {

            var $newObject = $mainContentRoomsToClone.clone().appendTo($contItemRooms);
            $currentTotal++;
            $newObject.attr("data-num-item-room", $currentTotal);
            $("span.text-room", $newObject).text((_language == 'es' ? "Habitación " : "Room ") + $currentTotal + ":");

            // adults
            $("div.form-item-hotel-total-adults-1", $newObject).removeClass("form-item-hotel-total-adults-1").addClass("form-item-hotel-total-adults-" + $currentTotal);
            $("label[for='edit-hotel-total-adults-1']", $newObject).attr("for", "edit-hotel-total-adults-" + $currentTotal);
            $("select#hotel_total_adults-1", $newObject).attr("id", "hotel_total_adults-" + $currentTotal);
            $("select[name='hotel_total_adults-1']", $newObject).attr("name", "hotel_total_adults-" + $currentTotal);

            //children
            $("div.form-item-hotel-total-children-1", $newObject).removeClass("form-item-hotel-total-children-1").addClass("form-item-hotel-total-children-" + $currentTotal);
            $("label[for='edit-hotel-total-children-1']", $newObject).attr("for", "edit-hotel-total-children-" + $currentTotal);
            $("select#edit-hotel-total-children-1", $newObject).attr("id", "edit-hotel-total-children-" + $currentTotal);
            $("select[name='hotel_total_children-1']", $newObject).attr("name", "hotel_total_children-" + $currentTotal);
            $("label[for='edit-age-children-1']", $newObject).attr("for", "edit-age-children-" + $currentTotal);
            var $currentObject = $("div[data-num-item-room='" + $currentTotal + "']");

            /*$("select[data-children-hotel='age']", $newObject).attr("id", "age_children_hotel-" + $currentTotal + "-1").chosen();
            $("select[data-children-hotel='age']", $newObject).attr("name", "age_children_hotel-" + $currentTotal + "-1").chosen();
            $("select[data-children-hotel='age']", $newObject).removeAttr("data-required");
			*/
            i++;
        }
    };

    var _cloneAgeChildrens = function($currentTotal, $totalToClone, $mainSelectToClone, $mainContentAgeChildren) {
        var i = 1;
        while (i <= $totalToClone) {
            $currentTotal++;
            var $newObject = $mainSelectToClone.clone().appendTo($mainContentAgeChildren);
            var _currentItem = $newObject.closest("[data-items-rooms='age']").attr("data-num-item-room");
            $newObject.attr("id", "age_children_hotel-" + _currentItem + "-" + $currentTotal);
            $newObject.attr("name", "age_children_hotel-" + _currentItem + "-" + $currentTotal);
            $newObject.attr("data-required", 1);
            $newObject.chosen();
            i++;
        }
    };

    var _removeAgeChildren = function($item, $mainContentAgeChildren) {
        var i = 1;
        $("select[data-children-hotel='age']", $mainContentAgeChildren).each(function() {
            $(this).removeAttr("data-required");
            if (i > $item) {
                $(this).next("div.chosen-container").remove();
                $(this).remove();
            }
            i++;
        });
    };

    var _eventChangeChildren = function($object) {
        var $mainContentAgeChildren = $(".total-age-children-hotel", $object);
        $mainContentAgeChildren.hide();
        $("select[data-dropdown-children='age']", $object).off().on("change", function() {
            var $this = $(this);
            var $value = parseInt($this.val());
            var _currentItem = $this.closest("[data-items-rooms='age']").attr("data-num-item-room");
            var $totalAge = $("select[data-children-hotel='age']", $mainContentAgeChildren).length;
            var $mainSelectToClone = $("select#age_children_hotel-" + _currentItem + "-1", $mainContentAgeChildren);
            if ($value === 0) {
                $mainContentAgeChildren.hide();
                _removeAgeChildren(1, $mainContentAgeChildren);
            } else {
                $mainSelectToClone.attr("data-required", 1);
                if ($value > $totalAge) {
                    var $totalToClone = ($value - $totalAge);
                    _cloneAgeChildrens($totalAge, $totalToClone, $mainSelectToClone, $mainContentAgeChildren);
                } else if ($value < $totalAge) {
                    _removeAgeChildren($value, $mainContentAgeChildren);
                }
                $mainContentAgeChildren.fadeIn("fast");
            }
        });
    };

    var _init = function() {
        var
                $contModules = $("#cont-modules"),
                $formHotels = $("form#ctp-hotels-form"),
                $selectRooms = $("select[name='hotel_rooms']", $formHotels),
                $contItemRooms = $("#cont-hotel-rooms", $formHotels),
                $contentChildren = $("div[data-num-item-room='1']", $formHotels),
                $checkin = $("input#hotel_checkin", $formHotels),
                $checkout = $("input#hotel_checkout", $formHotels);
		
		_language = $contModules.attr("data-language");
		
        $selectRooms.off().on("change", function() {
            var $this = $(this);
            var $value = $this.val();
            var $mainContentRoomsToClone = $("div[data-num-item-room='1']", $contItemRooms);
            var $totalRooms = $("div[data-items-rooms='age']", $contItemRooms).length;
            if ($value === 1) {
                _removeContentAge(1, $contItemRooms);
            } else {
				console.log("value: ", $value, " totalRooms: ", $totalRooms);
                if ($value > $totalRooms) {
                    var $totalToClone = ($value - $totalRooms);
                    _cloneContentAge($totalRooms, $totalToClone, $mainContentRoomsToClone, $contItemRooms);
                } else if ($value < $totalRooms) {
                    _removeContentAge($value, $contItemRooms);
                }
            }
            //$mainContentAgeChildren.hide();
            //$("label", $newObject).remove();
        });

        $("#btn_submit_hotels", $formHotels).off().on("click", function(e) {
            e.preventDefault();
            var $this = $(this);
            $this.hide();
            $("img#ajax-loader", $formHotels).show();
            $(".contenedor-modulo-express").fadeOut("fast", function(){
                $(this).empty();
            });
            $(".contentmetodopagoajax").fadeOut("fast", function(){
                $(this).empty();
            });
            var rulesErrors = {};

            var $contError = $("div#alert-error", $formHotels);
            var $selectChild = $("select#hotel_total_children", $formHotels);

            $contError.hide().html("");

            var $objectChild = $("option:selected", $selectChild);
            $.each($objectChild, function() {
                if ($(this).val() > 0) {
                    rulesErrors['child'] = true;
                    return;
                }
            });
            
            Das.MainForm.validate($formHotels, rulesErrors, function($result) {
                _clearFormError($formHotels);
                var $isSubmit = true;
                if ($result !== true) {
                    var $input = $("[name='" + $result.input + "']", $formHotels);
                    var $error = $.trim($("input[name='error-" + $result.error + "']", $formHotels).val());
                    $input.addClass("error").focus();
                    var $errorContent = $("div#alert-error");
                    $errorContent.html($error).show();
                    Das.Main.scrollTo($errorContent);
                    $isSubmit = false;
                }

                if ($isSubmit){
                    $(".contentLoading").show();
                    $formHotels.submit();
                }else {
                    $("img#ajax-loader", $formHotels).hide();
                    $this.show();
                }

            });
        });

        /*var $formHiddenHotels = $("form#formHiddenHotels");
         var $iframeHotels = $("iframe#iframeHotels");
         if ($formHiddenHotels.length > 0) {
         $("input#btnSubmitIframeHotels", $formHiddenHotels).click();
         }*/

        //_eventChangeChildren($contentChildren);
        Das.Main.loadDatePicker($checkin, $checkout, $("#hotel_total_night"));
        
        
        var $thisField = $("input[data-autocomplete='hotel']", $formHotels);
        var $field = 'targetId';
        var url = "./ctp_hotels/hotelsList/json";
		
        var $objButtonSubmit = $("button.form-submit", $formHotels);
        
        Das.Main.autoCompleteField($thisField, $field, null, url, $objButtonSubmit, $formHotels);
        
        $("input#hotel_without_date").off().on("change", function() {
            if ($(this).is(":checked")) {
                $(".hasDatepicker", $formHotels).attr("disabled", true);
            } else {
                $(".hasDatepicker", $formHotels).attr("disabled", false);
            }
        });

        //$("#cont-submit-hotels", $formHotels).append("<span><img id='ajax-loader' src='' /></span>");
    };

    var _clearFormError = function($form) {
        $("input,select", $form).each(function() {
            $(this).removeClass("error");
        })
    };

    Das.Hotels = {
        init: _init
    };

})(jQuery, $);