<?php
global $base_url, $language;

$formHotels = drupal_get_form(module_custom_name_hotels . '_form');
if (isset($_SESSION["paramsFormHotels"])){
    $dataPost = unserialize($_SESSION["paramsFormHotels"]);
    unset($_SESSION["paramsFormHotels"]);
}
?>
<div id="cont-modules" data-language="<?php echo $language->language ?>">
    <div class="contentLoading" style="display: none;"></div>
    <div id="cont-ctp-main">
        <div class="cont-ctp-tabs" id="ctp_flights">
            <div class="cont-ctp-tabs" id="ctp_hotels">
                <?php print drupal_render($formHotels); ?>
            </div>
        </div>
    </div>
</div>
<script>
    jQuery(function() {
        var $ = jQuery.noConflict();
        $(".ctp-cont-submit").append("<span><img id='ajax-loader' src='' /></span>");
        $("img#ajax-loader").attr("src", '<?php echo $base_url . '/' . drupal_get_path('module', module_custom_name_main) . '/images/ajax-loader.gif' ?>');
        $("img#ajax-loader").hide();
        
        // Muestra el mensaje de error interno
        var messageForm = "<?php echo isset($dataPost["message"]) ? $dataPost["message"] : '' ; ?>";
        if(messageForm) {
            jQuery("#alert-error").text(messageForm).show();
            jQuery("html, body").scrollTo("#alert-error", 800);
        }
    });
</script>