<?php

/*
 * @file MainUtils.class.php
 * @author : Elkin M. Salcedo C. <esalcedo@iatai.com>
 * 
 */

class MainUtils {
    /*
     * function: getRemoteIp()
     * devuelve la Ip, donde se esta ejecutando la operacion
     */

    public static function getRemoteIp() {
        $remoteIp = $_SERVER['REMOTE_ADDR'];
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            $remoteIp = $_SERVER['REMOTE_ADDR'];
        return $remoteIp;
    }

    /*
     * function: getCurrentDate()
     * devuelve la Fecha actual del servidor
     */

    public static function getCurrentDate() {
        return date('Y-m-d G:i:s');
    }

    /*
     * function: insertToDataBase()
     * Ejecuta la Insercion Row a MySql
     */

    public static function insertToDataBase($tableName, $array_data) {
        return db_insert($tableName)->fields($array_data)->execute();
    }

    /*
     * function: updateToDataBase()
     * Ejecuta un Update Row a MySql
     */

    public static function updateToDataBase($tableName, $array_data, $id) {
        $result = db_update($tableName)
                ->fields($array_data)
                ->condition('id', $id, '=')
                ->execute();

        return $result;
    }

    /*
     * function: queryToDataBase()
     * Ejecuta una sentencia
     */

    public static function queryToDataBase($tableName, $fieldsToReturn, $fieldToSearch, $value) {
        $result = db_query("SELECT " . $fieldsToReturn . " FROM " . $tableName . " WHERE " . $fieldToSearch . " LIKE '%" . $value . "%'");
        return $result;
    }

    public static function generateKey() {
        return substr(strtoupper(md5(uniqid(rand(), true))), 0, 6);
    }

    /* Compress file y convert to zip */

    public static function compressFile($source, $filename, $fileNameZip) {

        $zip = new ZipArchive();
        if (($zip->open($fileNameZip, ZipArchive::CREATE)) !== true) {
            die('Error: Unable to create zip file');
        }
        $zip->addFile($source, $filename);
        $zip->close();
    }

    /**
     * Busca un campo de una taxonomia por el tid.
     *
     * @return string con los datos del campo.
     * @param string $campo nombre del campo a traer de la taxonomia.
     * @param string $tid id de taxonomia para buscar. 
     */
    public static function get_term_taxonomy($campo, $tid) {
        $campo = strtolower($campo);
        $result = db_select('field_data_field_' . $campo, 'fic')->fields('fic', array('field_' . $campo . '_value'))->condition('entity_id', $tid, '=')->execute()->fetchAssoc();
        return($result['field_' . $campo . '_value']);
    }

    /**
     * Busca una taxonomia y retorna un array para un select.
     *
     * @return array con los datos de la taxonomia.
     * @param string $nametaxo nombre de la taxonomia.
     * @param string $namecamp nombre del campo de la taxonomia para la key del array a retornar. 
     * @param string $namedefault nombre item por defecto para el select.
     */
    public static function get_date_taxonomytoselect($nametaxo, $namecamp = false, $namedefault = false, $keydefault = "*") {
        $taxonomia = taxonomy_vocabulary_machine_name_load($nametaxo);
        $taxonomia_especifica = taxonomy_get_tree($taxonomia->vid);
        $taxonomia_array = array();
        $taxonomia_array[$keydefault] = ($namedefault != false) ? $namedefault : t("any");
        foreach ($taxonomia_especifica as $item) {
            /* $key=($namecamp!=false)?MainUtils::get_term_taxonomy($namecamp,$item->tid):$item->tid;
              $value = $item->name;
              if($boolValid==false){
              $taxonomia_array[$key] = $value; // Array de opciones para el campo SELECT pa�s
              }
              else{
              if(isset($key) and !empty($key)){
              $taxonomia_array[$key] = $value; // Array de opciones para el campo SELECT pa�s
              }
              }
             */
            $key = ($namecamp != false) ? MainUtils::get_term_taxonomy($namecamp, $item->tid) : $item->tid;
            $value = t($item->name);
            $taxonomia_array[$key] = $value; // Array de opciones para el campo SELECT pa�s
        }
        return $taxonomia_array;
    }

    public static function getContentsByType($contentTypeName) {
        $query = new EntityFieldQuery();
        $result = $query->entityCondition('entity_type', 'node')
                ->entityCondition('bundle', $contentTypeName)
                ->execute();
        return node_load_multiple(array_keys($result['node']));
    }

    public static function formmatDate($format, $separator, $value) {
        $currentSeparator = "/";
        $findSeparator = strpos($value, "-");
        if ($findSeparator)
            $currentSeparator = "-";

        list ($month, $day, $year) = explode($currentSeparator, $value);
        list ($format1, $format2, $format3) = explode("/", $format);

        if ($format1 === "Y" && $format2 === "M" && $format3 === "D") {
            $formmatedDate = $year . $separator . $month . $separator . $day;
        } elseif ($format1 === "M" && $format2 === "D" && $format3 === "Y") {
            $formmatedDate = $month . $separator . $day . $separator . $year;
        } elseif ($format1 === "M" && $format2 === "Y" && $format3 === "D") {
            $formmatedDate = $month . $separator . $year . $separator . $day;
        } elseif ($format1 === "D" && $format2 === "M" && $format3 === "Y") {
            $formmatedDate = $day . $separator . $month . $separator . $year;
        } elseif ($format1 === "Y" && $format2 === "D" && $format3 === "M") {
            $formmatedDate = $year . $separator . $day . $separator . $month;
        }

        return $formmatedDate;
    }

    public static function redirect_post($url, array $postarray) {
        $string = '<html><title>Travel - Allegra</title><head><style>
                            /*.contentLoading {
                            background-attachment: scroll, scroll;
                            background-clip: border-box, border-box;
                            background-image: url("./sites/all/modules/custom/clubmiles_main/images/clubmiles-logo-m1.png");
                            background-origin: padding-box;
                            background-position: center center;
                            background-repeat: no-repeat;
                            display: none;
                            position: absolute;
                            float: none !important;
                            top: 40%;
                            left: 40%;
                            z-index: 3000 !important;
                            }*/
                </style></head><body>';
        $string .= '<form method="post" name="formsend" action="' . $url . '" target="_parent">';

        if ($postarray != null) {
            foreach ($postarray as $postfield => $postvalue) {
                $string .= '<input type="hidden" name="' . $postfield . '" value="' . $postvalue . '">';
            }
        }

        $string .= '</form>';
        $string .= '<div class="contentLoading" style="display: block;">';
        $string .= '<div style="margin-top: 60px;"><img src="./sites/all/modules/custom/clubmiles_main/images/preload_clubmiles.gif" /></div></div>';
        $string .= '<script>document.formsend.submit();</script></body></html>';

        echo $string;
        exit;
    }
    
    public static function sendDataByGet($url, array $postarray) {
        $string = '<html><title>Travel - Allegra</title><head><style>
                            /*.contentLoading {
                            background-attachment: scroll, scroll;
                            background-clip: border-box, border-box;
                            background-image: url("./sites/all/modules/custom/clubmiles_main/images/clubmiles-logo-m1.png");
                            background-origin: padding-box;
                            background-position: center center;
                            background-repeat: no-repeat;
                            display: none;
                            position: absolute;
                            float: none !important;
                            top: 40%;
                            left: 40%;
                            z-index: 3000 !important;
                            }*/
                </style></head><body>';
        $string .= '<form method="get" name="formsend" action="' . $url . '" target="_self">';

        if ($postarray != null) {
            foreach ($postarray as $postfield => $postvalue) {
                $string .= '<input type="hidden" name="' . $postfield . '" value="' . $postvalue . '">';
            }
        }

        $string .= '</form>';
        $string .= '<div class="contentLoading" style="display: block;">';
        //$string .= '<div style="margin-top: 60px;"><img src="./sites/all/modules/custom/clubmiles_main/images/preload_clubmiles.gif" /></div></div>';
        $string .= '<script> document.formsend.submit(); </script></body></html>';

        echo $string;
        exit;
    }
    
    public static function sendDataHotels($url, array $postarray) {
        $string = '<html><title>Travel - Allegra</title><head><style>
                            /*.contentLoading {
                            background-attachment: scroll, scroll;
                            background-clip: border-box, border-box;
                            background-image: url("./sites/all/modules/custom/clubmiles_main/images/clubmiles-logo-m1.png");
                            background-origin: padding-box;
                            background-position: center center;
                            background-repeat: no-repeat;
                            display: none;
                            position: absolute;
                            float: none !important;
                            top: 40%;
                            left: 40%;
                            z-index: 3000 !important;
                            }*/
                </style></head><body>';
        $string .= '<form method="get" name="formsend" action="' . $url . '" target="_self">';

        if ($postarray != null) {
            foreach ($postarray as $postfield => $postvalue) {
                $string .= '<input type="hidden" name="' . $postfield . '" value="' . $postvalue . '">';
            }
        }
        
        $string .= '</form>';
        $string .= '<div class="contentLoading" style="display: block;">';
        //$string .= '<div style="margin-top: 60px;"><img src="./sites/all/modules/custom/clubmiles_main/images/preload_clubmiles.gif" /></div></div>';
        $string .= '<script>document.formsend.submit();</script></body></html>';

        echo $string;
        exit;
    }

}