if (typeof Das === "undefined")
    var Das = {};

(function($) {

    var _validate = function($form, rulesErrors, callback) {
        var $return = true;
        $("input[data-required='1'],select[data-required='1']", $form).each(function() {
            var
                    $this = $(this),
                    $elementName = $this.attr("name"),
                    $elementError = $this.attr("error-element"),
                    $tagName = $this.prop('tagName'),
                    $value = $.trim($this.val())
            
            if (typeof $this.attr("id") === 'undefined')
                return;
            
            if ($tagName === "INPUT" && $value.length < 1) {
                if ($elementName in rulesErrors)
                    return;
                
                $return = {'input': $elementName, 'error': $elementError};
                return false;
            }else if ($tagName === "SELECT" && 'child' in rulesErrors) {
                if ($("option:selected", $this).val().length < 1) {
                    $return = {'input': $elementName, 'error': 'select_childs'};
                    return false;
                }
            } else if ($tagName === "SELECT") {
                if ($("option:selected", $this).val() < 1) {
                    $return = {'input': $elementName, 'error': $elementError};
                    return false;
                }
            }
        });
        callback.call(this, $return);
    };


    Das.MainForm = {
        validate: _validate
    };

})(jQuery, $);