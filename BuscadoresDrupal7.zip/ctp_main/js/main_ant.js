/*
 * 
 * @file : main.js
 * @author : Elkin M. Salcedo C. <esalcedo@iatai.com>
 */
var ga = function() {
};
jQuery(function() {
    var $ = jQuery.noConflict();

    /* Load view */
    var _renderView = function(module, type, callback) {
        $("#cont-modules").load(module + '/view', {'type': type}, function(result) {
            callback.call(this, result);
        });
    };

    /*Get Content by json */

    var _json = function(module, callback) {
        $.ajax({
            type: 'POST',
            url: module + '/json',
            dataType: 'json',
            success: function(result) {
                callback.call(this, result);
            }
        });
    };

    var _loadDatePickerLanguage = function(lang) {

        switch (lang) {
            case 'en':
                $.datepicker.regional['en'] = {
                    closeText: 'Done',
                    prevText: 'Prev',
                    nextText: 'Next',
                    currentText: 'Today',
                    monthNames: ['January', 'February', 'March', 'April', 'May', 'June',
                        'July', 'August', 'September', 'October', 'November', 'December'],
                    monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
                    dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                    dayNamesMin: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                    weekHeader: 'Wk',
                    dateFormat: 'mm/dd/yy',
                    firstDay: 1,
                    isRTL: false,
                    showMonthAfterYear: false,
                    yearSuffix: ''};
                $.datepicker.setDefaults($.datepicker.regional['en']);
                break;

            case 'es':
                $.datepicker.regional['es'] = {
                    closeText: 'Cerrar',
                    prevText: '&#x3c;Ant',
                    nextText: 'Sig&#x3e;',
                    currentText: 'Hoy',
                    monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                        'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                    monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
                        'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
                    dayNames: ['Domingo', 'Lunes', 'Martes', 'Mi&eacute;rcoles', 'Jueves', 'Viernes', 'S&aacute;bado'],
                    dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mi&eacute;', 'Juv', 'Vie', 'S&aacute;b'],
                    dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'S&aacute;'],
                    weekHeader: 'Sm',
                    dateFormat: 'mm/dd/yy',
                    firstDay: 1,
                    isRTL: false,
                    showMonthAfterYear: false,
                    yearSuffix: ''};
                $.datepicker.setDefaults($.datepicker.regional['es']);
                break;
        }
        ;
    };

    /* Load DatePicker function */
    var _loadDatePicker = function($objDateDeparture, $objDateReturning, $object) {

        $objDateDeparture.datepicker({
            dateFormat: "mm/dd/yy",
            minDate: 0,
            numberOfMonths: (Modernizr.touch ? 1 : 2),
            onClose: function(selectedDate) {
                if (typeof $objDateReturning !== "undefined") {
                    var elementDate = selectedDate;
                    var elementArray = elementDate.split('/');
                    var daySelect = elementArray[1];
                    var monthSelect = elementArray[0];
                    var yearSelect = elementArray[2];
                    var dateObj = new Date(yearSelect, monthSelect - 1, daySelect);
                    //var p = new Date(Date.parse(dateObj) + 86400000);
                    var p = new Date(Date.parse(dateObj));
                    var curr_date = p.getDate();
                    var curr_month = p.getMonth();
                    curr_month++;
                    var curr_year = p.getFullYear();
                    var newdate = curr_month + "/" + curr_date + "/" + curr_year;
                    $objDateReturning.datepicker("option", "minDate", newdate);
                    if (typeof $object !== 'undefined')
                        _diffOfDays($objDateDeparture, $objDateReturning, $object);
                }
            }
        });
        if ($objDateDeparture.val().length < 1)
            $objDateDeparture.datepicker("setDate", new Date());

        if (typeof $objDateReturning !== "undefined") {
            $objDateReturning.datepicker({
                dateFormat: "mm/dd/yy",
                minDate: 0,
                numberOfMonths: (Modernizr.touch ? 1 : 2),
                onClose: function(selectedDate) {
                    $objDateDeparture.datepicker("option", "maxDate", selectedDate);
                    if (typeof $object !== 'undefined')
                        _diffOfDays($objDateDeparture, $objDateReturning, $object);
                }
            });
            if ($objDateReturning.val().length < 1)
                $objDateReturning.datepicker("setDate", new Date());
        }
    };

    /* Get days number from dates */
    var _diffOfDays = function($dateOne, $dateTwo, $object) {
        if ($dateOne.val().length > 0 && $dateTwo.val().length > 0) {
            var $start = $dateOne.datepicker('getDate');
            var $end = $dateTwo.datepicker('getDate');
            var $diffdays = ($end - $start) / 1000 / 60 / 60 / 24;
            $object.html($diffdays);
        }
    }

    // Ejecuta una animacion de scroll top
    var _scrollTo = function($container) {
        var $contScroll = $container.offset().top - 50;
        $('html:not(:animated),body:not(:animated)').animate({scrollTop: $contScroll}, 800);
    };

    var _clearIframe = function() {
        $(".content_option_trip").hide();
    };

    var _autoCompleteField = function($thisField, $field, $thisHiddenName, url, $objButtonSubmit, $objectContent) {

        $thisField.autocomplete({
            source: url,
            minLength: 3,
            cache: false,
            highlight: true,
            scroll: true,
            select: function(event, ui) {
                var $obj = $();
                if ($field === null)
                    $obj = $('#' + this.id + $thisHiddenName, $objectContent);
                else
                    $obj = $('#' + $field, $objectContent);

                $obj.val(ui.item.id);

                // Codifica el HTML, para que muestre el texto sin codigo
                $(this).val(jQuery('<div />').html(ui.item.label).html().replace(/\&amp;/g, '&'));
                return false;
            },
            focus: function(event, ui) {
                // Codifica el HTML, para que muestre el texto sin codigo
                $(this).val(jQuery('<div />').html(ui.item.label).html().replace(/\&amp;/g, '&'));
                return false;
            },
            search: function(response) {
                $objButtonSubmit.attr("disabled", true);
                if (response) {
                    setTimeout(function() {
                        $objButtonSubmit.attr("disabled", false);
                    }, 1000);
                }
            }
        }).data("autocomplete")._renderItem = function(ul, item) {
            return $("<li></li>")
                    .data("item.autocomplete", item)
                    .append($("<a></a>").html(item.label))
                    .appendTo(ul);

        };
    };

    var _init = function() {

        var $contModules = $('#cont-modules');
        var $contMenuModule = $(".ctp-module-menu");
        $("ul.ctp-tabs-modules li a[data-ctp-menu]", $contMenuModule).off().on("click", function(e) {
            e.preventDefault();
            var $this = $(this);
            var $moduleName = $this.attr("data-module-name");
            var currentAttrValue = $this.attr('href');
            $('#cont-modules ' + currentAttrValue).fadeIn().siblings().hide();
            $this.parent('li').addClass('active').siblings().removeClass('active');
            $("input[name='package_type']", $contMenuModule).each(function() {
                $(this).attr("checked", false);
            });

            switch ($moduleName) {
                case 'ctp_flights':
                    $("div#alert-error").hide().html("");
                    _clearIframe();
                    break;
                case 'ctp_hotels':
                    $("div#alert-error").hide().html("");
                    _clearIframe();
                    break;
                case 'ctp_cars':
                    $("div#alert-error").hide().html("");
                    _clearIframe();
                    break;
                case 'ctp_cruises':
                    $("div#alert-error").hide().html("");
                    _clearIframe();
                    break;
                case 'ctp_things':
                    $("div#alert-error").hide().html("");
                    _clearIframe();
                    break;
                case 'ctp_travelprotection':
                    $("div#alert-error").hide().html("");
                    _clearIframe();
                    break;
            }
        });

        var
                $formFlyDefault = $("form#ctp-flights-form"),
                $formFlyMultiple = $("form#ctp-flights-multiple-form"),
                $formHotels = $("form#ctp-hotels-form"),
                $formCars = $("form#ctp-cars-form"),
                $formCruises = $("form#ctp-cruises-form"),
                $formThings = $("form#ctp-things-form"),
                $formTravel = $("form#ctp-travelprotection-form"),
                $formTravel2 = $("form#ctp-travelprotection-custom-form"),
                $formTrip = $("form#ctp-customtrip-form");

        if ($formFlyDefault.length > 0 && $formFlyMultiple.length > 0)
            Das.Flight.init();

        if ($formHotels.length > 0)
            Das.Hotels.init();

        if ($formCars.length > 0)
            Das.Cars.init();

        if ($formCruises.length > 0)
            Das.Cruises.init();

        if ($formThings.length > 0)
            Das.Things.init();

        if ($formTravel.length > 0 || $formTravel2.length > 0)
            Das.TravelProtection.init();

        if ($formTrip.length > 0)
            Das.CustomTrip.init();

        _loadDatePickerLanguage('es');
        $("form").validate({
            lang: 'es'
        });
    };

    Das.Main = {
        init: _init,
        renderView: _renderView,
        loadDatePicker: _loadDatePicker,
        diffOfDays: _diffOfDays,
        scrollTo: _scrollTo,
        autoCompleteField: _autoCompleteField,
        json: _json
    };

    _init();
});