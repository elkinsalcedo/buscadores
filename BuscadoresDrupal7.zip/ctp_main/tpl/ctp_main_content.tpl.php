<?php
$formFlight = drupal_get_form(module_custom_name_flights . '_form');
$formMultipleFlight = drupal_get_form(module_custom_name_flights . '_multiple_form');
$formHotels = drupal_get_form(module_custom_name_hotels . '_form');
$formCars = drupal_get_form(module_custom_name_cars . '_form');
//$formCruises = drupal_get_form(module_custom_name_cruises . '_form');
$formThings = drupal_get_form(module_custom_name_things . '_form');
$formTravelExpress = drupal_get_form(module_custom_name_travel_protection . '_form');
$formTravelCustom = drupal_get_form(module_custom_name_travel_protection . '_custom_form');

$formCustomTrip = drupal_get_form(module_custom_name_trip . '_form');

?>

<div id="cont-modules">
    <div class="contentLoading" style="display: none;"></div>
    <div class="ctp-module-menu">
        <ul class="ctp-tabs-modules">
            <li class="active flights"><a data-ctp-menu="1" href="#ctp_flights" id="btn-menu-flight" data-module-name="ctp_flights"><?php echo t("Vuelos"); ?></a></li>
            <li class="hotels"><a data-ctp-menu="1" href="#ctp_hotels" id="btn-menu-hotel" data-module-name="ctp_hotels"><?php echo t("Hoteles"); ?></a></li>
            <li class="things"><a data-ctp-menu="1" href="#ctp_things" id="btn-menu-thingstodo" data-module-name="ctp_things"><?php echo t("Actividades en Destino"); ?></a></li>
			<!--li class="marketplace"><a href="javascript:void(0);" id="btn-menu-marketplace"><?php //echo t("Marketplace"); ?></a></li-->
        </ul>
    </div>
    <div id="cont-ctp-main">
        <div class="ctp-module-loader" style="display:none;">Loading...</div>
        <div class="cont-ctp-tabs" id="ctp_flights">
            <div data-rel="ctp-form-fly" class="cont-form-fly-default">
                <?php //print drupal_render($formFlight); ?>
            </div>
            <div data-rel="ctp-form-fly" class="cont-form-fly-multiple" style="display: none;">
                <?php //print drupal_render($formMultipleFlight); ?>
            </div>
        </div>
        <div class="cont-ctp-tabs" id="ctp_hotels" style="display:none;">
            <?php //print drupal_render($formHotels); ?>
        </div>
        <!--div class="cont-ctp-tabs" id="ctp_cars" style="display:none;">
            <?php //print drupal_render($formCars); ?>
        </div-->
        <!--div class="cont-ctp-tabs" id="ctp_cruises" style="display:none;">
        <?php //print drupal_render($formCruises); ?>
        </div-->
        <div class="cont-ctp-tabs" id="ctp_things" style="display:none;">
            <?php //print drupal_render($formThings); ?>
        </div>
        <!--div class="cont-ctp-tabs" id="ctp_customtrip" style="display:none;">
            <?php //print drupal_render($formCustomTrip); ?>
        </div-->
        <!--div class="cont-ctp-tabs" id="ctp_travelprotection" style="display:none;">
            <?php
            /*$cotizacionObject = $_SESSION["obj_Credenciales"]->getobj_proteccion();
            $cotizationType = $cotizacionObject->gettipocotizacion();
            $cambTipoCotiza = $cotizacionObject->getCambTipoCotiza();
            $display1 = ($cotizationType ? 'block' : 'none');
            $display2 = ($cotizationType ? 'none' : 'block');

            if ($cotizationType || $cambTipoCotiza):
                ?>
                <div id="ctp_travelprotection_1" style="display:<?php echo $display1; ?>">
                    <?php print drupal_render($formTravelExpress); ?>
                </div>
            <?php endif; ?>

            <?php if (!$cotizationType || $cambTipoCotiza): ?>
                <div id="ctp_travelprotection_2" style="display:<?php echo $display2; ?>">
                    <?php print drupal_render($formTravelCustom); ?>
                </div>
            <?php endif; */?>
        </div-->
    </div>
</div>