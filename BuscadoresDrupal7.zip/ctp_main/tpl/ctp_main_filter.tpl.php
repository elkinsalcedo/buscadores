<!-- SUBMIT FORM FLIGHTS -->
<?php
global $base_url;

if (isset($_SESSION["stringParameter"])):
    $dataPost = unserialize($_SESSION["stringParameter"]);
    unset($_SESSION["stringParameter"]);
    $typeFly = $dataPost["AirFlightType"];
    if (!isset($dataPost["error"])):
        ?>
        <div id="content-iframefly">
            <div class="contentFormFly" style="display: none;">
                <form target="_self" method="post" name="formHiddenFly" id="formHiddenFly" action="<?php echo base_url_fly . 'Vuelos/Resultados'; ?>">
                    <input type="text" />
                    <?php foreach ($dataPost as $key => $value) : ?>
                        <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value; ?>">
                    <?php endforeach; ?>
                    <button type="submit" id="btnSubmitFormFly" >Submit</button>
                </form>
            </div>
        </div>
        <script type="text/javascript">
            document.formHiddenFly.submit();
        </script>
    <?php else: ?>
        <!--div id="embed">
                <iframe sandbox="allow-same-origin allow-scripts allow-popups allow-forms" name="iframeFly" id="iframeFly" src="#"  frameborder="0" style="margin:0; width:100%; height:100%; border:none; overflow:hidden;" scrolling="yes"></iframe>
            </div-->
        <script type="text/javascript">
            window.onload = function() {
                jQuery(function($) {
                    //$('iframe').responsiveIframe({this: 'isnt', that: 'is', xdomain: '*'});
                    $("a[href='#ctp_flights']").trigger("click");
                    var flyType = '<?php echo $typeFly; ?>';
                    var $contentFly = $("#cont-flight-types");
                    switch (flyType) {
                        case 'RT' :
                            $("input:radio[value='1']", $contentFly).trigger("change");
                            break;
                        case 'OW' :
                            $("input:radio[value='2']", $contentFly).trigger("change");
                            break;
                        case 'MD' :
                            $("input:radio[value='3']", $contentFly).trigger("change");
                            break;
                    }

                    if ($(".alert").length > 0)
                        Das.Main.scrollTo($(".alert"));
                    
                     // Muestra el mensaje de error interno
                    var messageForm = "<?php echo isset($dataPost["message"]) ? $dataPost["message"] : '' ; ?>";
                    messageForm || ( messageForm = jQuery(".alert").hide().text().substring(15,250) );
                    if(messageForm) {
                        jQuery("#ctp_flights #alert-error").text(messageForm).show();
                        Das.Main.scrollTo($("#alert-error"));
                    }
                });
            };
        </script>
    <?php endif; ?>
<?php endif; ?>


<!-- SUBMIT FORM HOTELS -->
<?php
if (isset($_SESSION["paramsFormHotels"])):
    $dataPost = unserialize($_SESSION["paramsFormHotels"]);
    unset($_SESSION["paramsFormHotels"]);
    if (!isset($dataPost["error"])):
        ?>
        <div id="content-iframeHotels">
            <div class="contentFormHotels" style="display: none;">
                <form enctype="application/x-www-form-urlencoded" method="get" name="formHiddenHotels" id="formHiddenHotels" target="_self" action="<?php echo base_url_hotels . 'templates/379449/hotels/list/'; ?>">

                    <!--input type="hidden" name="pagename" value="ToSearchResults"-->
                    <input type="hidden" name="lang" value="es">
                    <input type="hidden" name="currency" value="USD">
                    <input type="hidden" name="secureUrlFromDataBridge" value="https://www.travelnow.com">
                    <input type="hidden" name="requestVersion" value="V2">
                    <?php foreach ($dataPost as $key => $value) : ?>
                        <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value; ?>">
                    <?php endforeach; ?>
                    <button type="submit" id="btnSubmitIframeHotels">Submit</button>
                </form>
            </div>
            <script type="text/javascript">
                document.formHiddenHotels.submit();
            </script>
        <?php else: ?>
            <script type="text/javascript">
                window.onload = function() {
                    jQuery(function($) {
                        $("a[href='#ctp_hotels']").trigger("click");

                        if ($(".alert").length > 0)
                            Das.Main.scrollTo($(".alert"));
                        
                         // Muestra el mensaje de error interno
                        var messageForm = "<?php echo isset($dataPost["message"]) ? $dataPost["message"] : '' ; ?>";
                        if(messageForm) {
                            jQuery("#ctp_hotels #alert-error").text(messageForm).show();
                            jQuery("html, body").scrollTo("#alert-error", 800);
                        }
                        
                    });
                };
            </script>
        </div>
    <?php endif; ?>
<?php endif; ?>

<!-- SUBMIT FORM CARS -->
<?php
if (isset($_SESSION["paramsFormCars"])):
    $dataPost = unserialize($_SESSION["paramsFormCars"]);
    unset($_SESSION["paramsFormCars"]);
    if (!isset($dataPost["error"])):
        ?>
        <div id="content-iframeCars">
            <div class="contentFormCars" style="display: none;">
                <form enctype="application/x-www-form-urlencoded" method="get" name="formHiddenCars" id="formHiddenCars" target="_self" action="<?php echo base_url_cars . 'nexres/start-pages/gateway.cgi'; ?>">

                    <input type="hidden" name="src" value="10024006">
                    <input type="hidden" name="engine" value="car">
                    <?php foreach ($dataPost as $key => $value) : ?>
                        <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value; ?>">
                    <?php endforeach; ?>
                    <button type="submit" id="btnSubmitIframeCars">Submit</button>
                </form>
            </div>
        </div>
        <script type="text/javascript">
            document.formHiddenCars.submit();
        </script>
    <?php else: ?>
        <script type="text/javascript">
            window.onload = function() {
                jQuery(function($) {
                    $("a[href='#ctp_cars']").trigger("click");

                    if ($(".alert").length > 0)
                        Das.Main.scrollTo($(".alert"));
                    
                    // Muestra el mensaje de error interno
                    var messageForm = "<?php echo isset($dataPost["message"]) ? $dataPost["message"] : '' ; ?>";
                    messageForm || ( messageForm = jQuery(".alert").hide().text().substring(15,250) );
                    if(messageForm) {
                        jQuery("#ctp_cars #alert-error").text(messageForm).show();
                        jQuery("html, body").scrollTo("#alert-error", 800);
                    }
                });
            };
        </script>
    <?php endif; ?>
<?php endif; ?>


<!-- SUBMIT FORM CRUISES -->
<?php
if (isset($_SESSION["paramsFormCruises"])):
    $dataPost = unserialize($_SESSION["paramsFormCruises"]);
    unset($_SESSION["paramsFormCruises"]);
    if (!isset($dataPost["error"])):
        ?>
        <div id="content-iframeCruises">
            <div class="contentFormCruises" style="display: none;">
                <form target="_self" enctype="application/x-www-form-urlencoded" method="get" name="formHiddenCruises" id="formHiddenCruises" action="<?php echo base_url_cruises . 'nexres/start-pages/gateway.cgi'; ?>">

                    <input type="hidden" name="engine" value="cruise">
                    <input type="hidden" name="Service" value="WCT">
                    <input type="hidden" name="src" value="10024006">
                    <input type="hidden" name="subAffiliateId" value="">
                    <input type="hidden" name="action" value="search">
                    <?php foreach ($dataPost as $key => $value) : ?>
                        <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value; ?>">
                    <?php endforeach; ?>
                    <button type="submit" id="btnSubmitIframeCruises">Submit</button>
                </form>
            </div>
        </div>
        <script type="text/javascript">
            document.formHiddenCruises.submit();
        </script>
    <?php else: ?>
        <script type="text/javascript">
            window.onload = function() {
                jQuery(function($) {
                    $("a[href='#ctp_cruises']").trigger("click");
                    if ($(".alert").length > 0)
                        Das.Main.scrollTo($(".alert"));
                });
            };
        </script>
    <?php endif; ?>
<?php endif; ?>


<!-- SUBMIT FORM OTHER ACTIVITIES -->
<?php
if (isset($_SESSION["paramsFormActivities"])):
    $dataPost = unserialize($_SESSION["paramsFormActivities"]);
    unset($_SESSION["paramsFormActivities"]);
    if (!isset($dataPost["error"])):
        ?>
        <div id="content-iframeActivities">
            <?php
            //$block = module_invoke('wtp_viator', 'block_view', 'filtro-actividades-viator', '', '', '', $dataPost);
            //print ($block["content"]);
            ?>
        </div>
    <?php endif; ?>
    <script type="text/javascript">
        window.onload = function() {
            jQuery(function($) {
                if ($(".alert").length > 0)
                    Das.Main.scrollTo($(".alert"));

                $("a[href='#ctp_things']").trigger("click");
                
                 // Muestra el mensaje de error interno
                var messageForm = "<?php echo isset($dataPost["message"]) ? $dataPost["message"] : '' ; ?>";
                if(messageForm) {    
                    jQuery("#ctp_things #alert-error").text(messageForm).show();
                    jQuery("html, body").scrollTo("#alert-error", 800);
                }
            });
        };
    </script>
<?php endif; ?>

<!-- SUBMIT FORM TRAVEL PROTECTIONS -->
<?php
if (isset($_SESSION["paramsFormTravelProtections"])):
    $dataPost = unserialize($_SESSION["paramsFormTravelProtections"]);
    unset($_SESSION["paramsFormTravelProtections"]);
    if (!isset($dataPost["error"])):
        ?>
        <div id="content-iframeTravelProtections">
            <div class="contentFormTravelProtections" style="display: none;">
                <form target="_self" method="post" name="formHiddenTravelProtections" id="formHiddenTravelProtections" action="<?php echo $base_url.'/travelprotection'; ?>">
                    <?php foreach ($dataPost as $key => $value) : ?>
                        <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value; ?>">
                    <?php endforeach; ?>
                    <button type="submit" id="btnSubmitTravelProtections">Submit</button>
                </form>
            </div>
        </div>
        <script type="text/javascript">
            document.formHiddenTravelProtections.submit();
        </script>
    <?php endif; ?>
    <script type="text/javascript">
        window.onload = function() {
            jQuery(function($) {
                if ($(".alert").length > 0)
                    Das.Main.scrollTo($(".alert"));

                $("a[href='#ctp_travelprotection']").trigger("click");
            });
        };
    </script>
<?php endif; ?>

<!-- SUBMIT FORM TRIP -->
<?php
if (isset($_SESSION["paramsFormTrip"])):
    $dataPost = unserialize($_SESSION["paramsFormTrip"]);
    unset($_SESSION["paramsFormTrip"]);
    if (!isset($dataPost["error"])):
        ?>
        <div id="content-iframeTrip">
            <div class="contentFormTrip" style="display: none;">
                <form target="_self" enctype="application/x-www-form-urlencoded" method="get" name="formHiddenTrip" id="formHiddenTrip" action="<?php echo base_url_customtrip . 'nexres/start-pages/gateway.cgi'; ?>">
                    <input type="hidden" name="engine" value="customtrip">
                    <input type="hidden" name="src" value="10024006">
                    <input type="hidden" name="action" value="search">
                    <?php foreach ($dataPost as $key => $value) : ?>
                        <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value; ?>">
                    <?php endforeach; ?>
                    <button type="submit" id="btnSubmitIframeTrip">Submit</button>
                </form>
            </div>
        </div>
        <script type="text/javascript">
            document.formHiddenTrip.submit();
        </script>
    <?php else: ?>
        <script type="text/javascript">
            window.onload = function() {
                jQuery(function($) {
                    if ($(".alert").length > 0)
                        Das.Main.scrollTo($(".alert"));

                    $("a#btn-menu-customtrip").trigger("click");
                    
                    // Muestra el mensaje de error interno
                    var messageForm = "<?php echo isset($dataPost["message"]) ? $dataPost["message"] : '' ; ?>";
                    if(messageForm){
                        jQuery("#ctp_customtrip #alert-error").text(messageForm).show();
                        jQuery("html, body").scrollTo("#alert-error", 800);
                    }
                });
            };
        </script>
    <?php endif; ?>
<?php endif; ?>
<div class="contentctptravelajax" style="display:none;"></div>
<div class="contentmetodopagoajax" style="display:none;"></div>
<script>

    jQuery(function() {
        var $ = jQuery.noConflict();
        $(".ctp-cont-submit").append("<span><img id='ajax-loader' src='' /></span>");
        $("img#ajax-loader").attr("src", '<?php echo $base_url . '/' . drupal_get_path('module', module_custom_name_main) . '/images/ajax-loader.gif' ?>');
        $("img#ajax-loader").hide();
    });
</script>