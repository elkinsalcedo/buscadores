<?php

/**
 * Nombre: ctp_things.class
 * Detalle: Controla todas las funciones para el modulo de things.
 * company: Iatai Andina
 * @author: John Fredy Velasco Bareño
 * fecha de creacion: Septiembre de 2014
 * @link jvelasco@iatai.com
 * @copyright 2014 - Iatai Andina - Todos los derechos reservados. 
 */
class ctp_things {
    
    /**
    * Constante para el nombre de la tabla para el campo de idviator.
    * @var string nombre de la tabla.
    * @access constant
    */
    const table_name_fielviator = 'field_data_field_dest_id_viator';
    
    /**
    * Genera la la lista para los paises habilitados en Viator desde la taxonomia.
    *
    * @return array con los datos la taxonomia paises.
    * @param array $temrBus con el texto digitado para buscar. 
    */
    static function getPaisesTaxonomi($temrBus){
        //SELECT dato.*,field.* FROM (bdb_taxonomy_vocabulary as taxo inner join bdb_taxonomy_term_data as dato on taxo.machine_name="paises" and taxo.vid=dato.vid and dato.name like ("%ale%")) inner join bdb_field_data_field_dest_id_viator as field on field.entity_id=dato.tid  group by dato.tid;        
        $query = db_select('taxonomy_vocabulary', 'taxo');
        $query->innerJoin('taxonomy_term_data', 'dato', "taxo.machine_name='paises' and taxo.vid=dato.vid and dato.name like ('%".$temrBus."%')");
        $query->innerJoin(ctp_things::table_name_fielviator, 'field', 'field.entity_id=dato.tid');
        $query->groupBy('tid');
        $query->fields('dato', array('name'));
        $query->fields('field', array('field_dest_id_viator_value'));
        $result = $query->execute();
        $result = $query->execute();
        $row_set = array();
        while($record = $result->fetchAssoc()) {
            $record['value'] = utf8_encode(htmlentities(stripslashes($record["name"])));
            $record['id'] = (int) $record["field_dest_id_viator_value"];            
            $row_set[]=$record;                                    
        }        
        return $row_set;        
    }

    /**
    * Cambia el formato de la fecha para enviar al api.
    *
    * @return string con la fecha con el formato correcto del api.
    * @param string $date con la fecha. 
    */    
    static function ctp_flights_formmat_date($date) {
        list ($month, $day, $year) = explode("/", $date);
        return $year . '-' . $month . '-' . $day;
    }

    /**
    * Obtiene el valor del tipo de viaje para enviar al api.
    *
    * @return string con el tipo correcto del api.
    * @param string $key con la llave a buscar. 
    */
    static function ctp_flights_types($key) {
        $arrayTypes = array(
            1 => "RT",
            2 => "OW",
            3 => "MD"
        );
        return $arrayTypes[$key];
    }
}

?>
