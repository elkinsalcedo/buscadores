if (typeof Das === "undefined")
    var Das = {};

(function($) {


    var _init = function() {
        var
                $formThings = $("form#ctp-things-form"),
                $flightDepartingDate = $("input#things_departing_date", $formThings),
                $flightReturingDate = $("input#things_returning_date", $formThings);

        $("#btn_submit_things", $formThings).off().on("click", function(e) {
            e.preventDefault();
            var $this = $(this);
            $this.hide();
            //$("img#ajax-loader", $formThings).show();
            var $targetId = $("input#targetId", $formThings);

            var rulesErrors = {};

            var $contError = $("div#alert-error", $formThings);
            $contError.hide().html("");
            if (parseInt($targetId.val()) + 0 < 1) {
                var $errorContent = $("div#alert-error");
                $errorContent.html("Por favor especifique un destino válido.").show();
                Das.Main.scrollTo($errorContent);
                $("img#ajax-loader", $formThings).hide();
                $this.show();
                return false;
            }

            Das.MainForm.validate($formThings, rulesErrors, function($result) {
                _clearFormError($formThings);
                if ($result !== true) {
                    var $input = $("[name='" + $result.input + "']", $formThings);
                    var $error = $.trim($("input[name='error-" + $result.error + "']", $formThings).val());
                    $input.addClass("error").focus();
                    var $errorContent = $("div#alert-error");
                    $errorContent.html($error).show();
                    Das.Main.scrollTo($errorContent);
                    $("img#ajax-loader", $formThings).hide();
                    $this.show();
                } else {
                    $(".contentLoading").show();
                    $formThings.submit();
                }

            });
        });

        var $thisField = $("input[data-autocomplete='things']", $formThings);
        var $field = 'targetId';
        var url = "./ctp_things/thingsList/json";
        var $objButtonSubmit = $("button.form-submit", $formThings);

        Das.Main.autoCompleteField($thisField, $field, null, url, $objButtonSubmit, $formThings);
        Das.Main.loadDatePicker($flightDepartingDate, $flightReturingDate, undefined);
        var $mainContent = $("#cont-submit-things", $formThings);
        var $loader = $("input#loader");
        if ($("img#ajax-loader", $mainContent).length < 1)
            $mainContent.append("<span><img style='display:none;' id='ajax-loader' src='" + $loader.val() + "' /></span>");
    };

    var _clearFormError = function($form) {
        $("input,select", $form).each(function() {
            $(this).removeClass("error");
        });
    };

    Das.Things = {
        init: _init
    };
})(jQuery, $);